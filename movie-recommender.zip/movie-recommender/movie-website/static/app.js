// ---------- 1. Flip a face-down card, then open that movie ----------
const deal = document.querySelector(".deal");

// When you press Back, browsers may show the old copy of the page (with the card still flipped).
// Reloading in that case deals three brand-new cards.
window.addEventListener("pageshow", (event) => {
  if (event.persisted && deal) window.location.reload();
});
if (deal) {
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  deal.querySelectorAll(".playing-card").forEach((card) => {
    card.addEventListener("click", () => {
      if (deal.classList.contains("has-pick")) return;        // only one pick per deal
      deal.classList.add("has-pick");
      card.classList.add("flipped");
      card.setAttribute("aria-label", "Opening " + card.querySelector(".card-face img").alt.replace("Poster of ", ""));
      setTimeout(() => { window.location.href = card.dataset.href; }, reduceMotion ? 150 : 1500);
    });
  });
}

// ---------- 2. Search suggestions (movie titles, actors, genres, directors) ----------
document.querySelectorAll(".search-form").forEach((form) => {
  const input = form.querySelector("input[name=q]");
  const list = form.querySelector("datalist");
  const placeholders = {
    movie: "Try 3 Idiots, Baahubali or Premam",
    actor: "Try Shah Rukh Khan, Nayanthara or Mohanlal",
    genre: "Try Comedy, Thriller or Romance",
    director: "Try Mani Ratnam or S. S. Rajamouli",
  };
  const currentType = () => form.querySelector("input[name=type]:checked").value;
  let timer;

  const loadSuggestions = () => {
    const q = input.value.trim();
    if (q.length < 2) { list.innerHTML = ""; return; }
    fetch(`/api/suggest?type=${currentType()}&q=${encodeURIComponent(q)}`)
      .then((r) => r.json())
      .then((items) => {
        list.innerHTML = "";
        items.forEach((text) => {
          const opt = document.createElement("option");
          opt.value = text;
          list.appendChild(opt);
        });
      })
      .catch(() => {});
  };

  input.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(loadSuggestions, 180); });
  form.querySelectorAll("input[name=type]").forEach((radio) =>
    radio.addEventListener("change", () => {
      input.placeholder = placeholders[radio.value];
      list.innerHTML = "";
      input.focus();
    })
  );
  input.placeholder = placeholders[currentType()];
});
