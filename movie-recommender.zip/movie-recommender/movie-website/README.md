# Teen Patti Talkies: Indian movie recommender website

## Run it
**Windows:** double-click `run_website.bat`. It installs what's needed the first time, starts the site and opens
your browser. Close its window to stop the website.

Or from a terminal: `pip install -r requirements.txt`, then `python app.py`, then open http://127.0.0.1:5000

## What's in the folder
| File | What it does |
|---|---|
| `run_website.bat` | Double-click to start the website |
| `download_posters.bat` | Optional: double-click once to download every real poster in advance |
| `app.py` | The Flask website: pages, search, recommendations, posters |
| `poster_art.py` | Draws a unique genre-based poster for films that have no real poster |
| `movies.csv`, `recommendations.json` | Made by `train_model.ipynb`: the movie table and the KNN top-20 similar movies for every film |
| `templates/`, `static/` | HTML pages, design, card-flip animation, search suggestions |
| `static/posters/` | Real posters, downloaded automatically the first time each movie is shown |
| `fetch_posters.py` | Optional: better posters + exact YouTube trailer links from TMDB (needs a free API key) |

## How each feature works
- **Three face-down cards:** each holds a random well-rated movie (IMDb 6.5+, 300+ votes). Clicking flips it and
  opens that movie. Coming back deals three new cards.
- **Search:** by movie title, actor or actress, genre or director, optionally filtered by language, with suggestions while typing.
- **Home page list:** at first it shows random well-rated movies. After you open a few films it shows
  "Because you watched": the trained KNN model's neighbours of the films you opened. No account is needed; the browser
  remembers your last 15 films (clear them with the link at the bottom of the page).
- **Movie page:** lead actor, lead actress, director, cast, IMDb rating, plot, "Watch trailer on YouTube" and 12 similar movies.

## Posters
1. The first time a movie is shown, the site finds its poster on Wikipedia, downloads it into `static/posters/`
   and uses that file from then on.
2. Films with no poster on Wikipedia get a poster drawn for them: the genre picks the artwork and colours, and the film's
   title, stars and director are printed on it, so every poster is different.
3. To download all real posters at once (about 10-20 minutes), double-click `download_posters.bat`.

If a real poster ever looks wrong, delete that film's file in `static/posters/` (named by its IMDb id, e.g. `tt4849438.jpg`).

## Before putting it online
Change `app.secret_key` in `app.py` to your own long random sentence, and set `debug=True` to `debug=False`.
