"""
Generates a unique movie-poster image (SVG) for films that have no real poster.

The genre picks the artwork and colours; the movie's id picks variations (background pattern,
position, angle, colour shift), so every film gets its own poster with its title, stars and director.
"""
import hashlib
import random
import re
from xml.sax.saxutils import escape

# genre -> (top colour, bottom colour, artwork colour, text colour)
THEMES = {
    "Action":      ("#d7261e", "#2b0303", "#ffb000", "#fff4e0"),
    "Romance":     ("#e9507a", "#3a0a2a", "#ffd1dc", "#fff0f4"),
    "Comedy":      ("#ffc928", "#d4471a", "#2b1600", "#fff8e0"),
    "Drama":       ("#2f5d8a", "#0b1730", "#f2d492", "#f4efe4"),
    "Thriller":    ("#1f4e5a", "#05141a", "#e8e8e8", "#e8f4f4"),
    "Crime":       ("#2a2a2a", "#050505", "#f5c518", "#f5f5f5"),
    "Horror":      ("#24412a", "#020a04", "#c8e6a0", "#e6f2dc"),
    "Mystery":     ("#4b2e83", "#120826", "#d9c6ff", "#f1eaff"),
    "Sci-Fi":      ("#1b3a8a", "#030a24", "#6ff2ff", "#e6fbff"),
    "Fantasy":     ("#6a2c91", "#1a0830", "#ffd27a", "#fff3dc"),
    "Family":      ("#f39c34", "#7a3410", "#fff1c9", "#fff7e8"),
    "Music":       ("#c2185b", "#2a0520", "#ffd54f", "#fff3f8"),
    "Musical":     ("#c2185b", "#2a0520", "#ffd54f", "#fff3f8"),
    "Sport":       ("#1e8e4a", "#06301a", "#ffffff", "#f0fff5"),
    "War":         ("#5b5b34", "#1c1c0c", "#e6d8a8", "#f4efdc"),
    "History":     ("#8a5a2b", "#2a160a", "#f3dcb0", "#fbf1dc"),
    "Biography":   ("#7a5a3a", "#251810", "#f0dcc0", "#fbf3e6"),
    "Adventure":   ("#2a9d8f", "#0c3a3a", "#f4a261", "#f4fbfa"),
    "Animation":   ("#ff6f3c", "#5a1aa0", "#fff04a", "#ffffff"),
    "Documentary": ("#4a5a6a", "#10161c", "#e0e6ec", "#f2f5f8"),
}
DEFAULT_THEME = ("#8c1c13", "#1a0705", "#f2c14e", "#fff4e0")


# ------------------------------------------------------------------ artwork (drawn around 0,0 in a ~200px box)
def art_action(a, k):
    return (f'<polygon fill="{a}" opacity=".35" points="0,-110 22,-38 95,-60 40,-8 105,40 30,32 20,110 -12,40 -90,80 -40,10 '
            f'-108,-30 -32,-34 -40,-102 0,-50"/>'
            f'<polygon fill="{a}" points="18,-95 -30,10 2,10 -16,95 36,-18 4,-18 26,-95"/>')

def art_romance(a, k):
    heart = "M0,30 C-60,-10 -45,-75 0,-45 C45,-75 60,-10 0,30 Z"
    return (f'<path d="{heart}" transform="translate(-28,-5) scale(1.35)" fill="{a}"/>'
            f'<path d="{heart}" transform="translate(42,22) scale(.95)" fill="none" stroke="{a}" stroke-width="7"/>')

def art_comedy(a, k):
    return (f'<circle r="80" fill="{a}"/><circle cx="-28" cy="-20" r="11" fill="{k}"/><circle cx="28" cy="-20" r="11" fill="{k}"/>'
            f'<path d="M-45,12 Q0,72 45,12 Z" fill="{k}"/>')

def art_comedy_wink(a, k):
    return (f'<circle r="80" fill="{a}"/><circle cx="-28" cy="-20" r="11" fill="{k}"/>'
            f'<path d="M15,-22 Q30,-34 45,-22" stroke="{k}" stroke-width="8" fill="none" stroke-linecap="round"/>'
            f'<path d="M-40,15 Q0,55 42,10" stroke="{k}" stroke-width="10" fill="none" stroke-linecap="round"/>')

def art_comedy_bubble(a, k):
    return (f'<path d="M-90,-70 H90 Q105,-70 105,-55 V25 Q105,40 90,40 H-20 L-55,80 L-45,40 H-90 Q-105,40 -105,25 V-55 '
            f'Q-105,-70 -90,-70 Z" fill="{a}"/>'
            f'<text x="0" y="12" text-anchor="middle" font-family="Impact, \'Arial Black\', sans-serif" font-size="64" '
            f'fill="{k}" transform="rotate(-6)">HA HA!</text>')

def mask(fill, cut, mouth_up):
    m = "M-22,25 Q0,45 22,25" if mouth_up else "M-22,38 Q0,18 22,38"
    return (f'<path d="M-45,-55 Q0,-75 45,-55 Q50,10 0,60 Q-50,10 -45,-55 Z" fill="{fill}"/>'
            f'<ellipse cx="-18" cy="-18" rx="10" ry="7" fill="{cut}"/><ellipse cx="18" cy="-18" rx="10" ry="7" fill="{cut}"/>'
            f'<path d="{m}" stroke="{cut}" stroke-width="7" fill="none" stroke-linecap="round"/>')

def art_drama(a, k):
    return (f'<g transform="translate(-30,-8) rotate(-14)">{mask(a, k, True)}</g>'
            f'<g transform="translate(38,22) rotate(12) scale(.85)" opacity=".75">{mask(a, k, False)}</g>')

def art_thriller(a, k):
    return (f'<path d="M-100,0 Q0,-75 100,0 Q0,75 -100,0 Z" fill="none" stroke="{a}" stroke-width="7"/>'
            f'<circle r="34" fill="{a}"/><circle r="14" fill="{k}"/><circle cx="-8" cy="-8" r="5" fill="{a}"/>')

def art_crime(a, k):
    bld = ""
    for x, h in [(-100, 70), (-72, 120), (-40, 90), (-10, 150), (22, 105), (52, 135), (82, 80)]:
        bld += f'<rect x="{x}" y="{70 - h}" width="28" height="{h}" fill="{k}" opacity=".9"/>'
    return f'<circle cx="40" cy="-55" r="38" fill="{a}"/>{bld}<rect x="-105" y="68" width="210" height="6" fill="{a}"/>'

def art_horror(a, k):
    tree = (f'<path d="M0,95 L0,10 M0,40 L-40,0 M-40,0 L-60,-10 M-40,0 L-45,-28 M0,25 L35,-15 M35,-15 L60,-20 M35,-15 L38,-45 '
            f'M0,10 L-8,-40" stroke="{k}" stroke-width="9" stroke-linecap="round" fill="none"/>')
    bat = "M0,0 Q-10,-10 -22,-4 Q-16,-14 -26,-18 Q-10,-18 0,-8 Q10,-18 26,-18 Q16,-14 22,-4 Q10,-10 0,0 Z"
    return (f'<circle cx="0" cy="-30" r="70" fill="{a}"/>{tree}'
            f'<path d="{bat}" transform="translate(-55,-80) scale(1.2)" fill="{k}"/>'
            f'<path d="{bat}" transform="translate(60,-95)" fill="{k}"/>')

def art_mystery(a, k):
    return (f'<circle cx="-15" cy="-15" r="55" fill="none" stroke="{a}" stroke-width="12"/>'
            f'<path d="M25,25 L80,80" stroke="{a}" stroke-width="20" stroke-linecap="round"/>'
            f'<text x="-15" y="5" text-anchor="middle" font-family="Georgia, serif" font-size="70" font-weight="bold" fill="{a}">?</text>')

def art_scifi(a, k):
    stars = "".join(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{a}"/>' for x, y, r in
                    [(-90, -80, 2.5), (70, -95, 2), (95, -30, 3), (-75, 60, 2), (80, 75, 2.5), (-20, -100, 1.8)])
    return (stars + f'<circle r="55" fill="{a}" opacity=".9"/>'
            f'<ellipse rx="100" ry="22" fill="none" stroke="{a}" stroke-width="7" transform="rotate(-18)"/>'
            f'<circle cx="-18" cy="-15" r="12" fill="{k}" opacity=".35"/>')

def art_fantasy(a, k):
    castle = (f'<path d="M-70,90 L-70,0 L-55,0 L-55,-15 L-45,-15 L-45,0 L-25,0 L-25,-55 L-10,-75 L5,-55 L5,0 L25,0 L25,-25 '
              f'L35,-25 L35,0 L55,0 L55,-40 L65,-55 L75,-40 L75,90 Z" fill="{k}" opacity=".85"/>')
    return (f'<path d="M30,-95 A50,50 0 1 0 75,-30 A40,40 0 1 1 30,-95 Z" fill="{a}"/>{castle}'
            + "".join(f'<path d="M{x},{y} l4,10 l10,4 l-10,4 l-4,10 l-4,-10 l-10,-4 l10,-4 Z" fill="{a}"/>'
                      for x, y in [(-80, -80), (-45, -100), (90, 10)]))

def art_family(a, k):
    return (f'<path d="M-80,10 L0,-70 L80,10 Z" fill="{a}"/><rect x="-60" y="10" width="120" height="80" fill="{a}"/>'
            f'<path d="M0,72 C-28,50 -22,26 0,40 C22,26 28,50 0,72 Z" fill="{k}" opacity=".7"/>')

def art_music(a, k):
    note = lambda x, y, s: (f'<g transform="translate({x},{y}) scale({s})"><ellipse cx="-12" cy="40" rx="18" ry="13" fill="{a}" '
                            f'transform="rotate(-20 -12 40)"/><rect x="2" y="-45" width="7" height="85" fill="{a}"/>'
                            f'<path d="M9,-45 Q40,-30 30,0 Q35,-25 9,-25 Z" fill="{a}"/></g>')
    return note(-35, 0, 1.4) + note(45, -25, 1.0) + note(55, 55, .7)

def art_sport(a, k):
    return (f'<circle r="62" fill="{a}"/><path d="M-62,0 Q0,-30 62,0 M-62,0 Q0,30 62,0 M0,-62 Q-30,0 0,62" stroke="{k}" '
            f'stroke-width="4" fill="none" opacity=".6"/>'
            + "".join(f'<rect x="{-130 + i * 6}" y="{-40 + i * 28}" width="{50 - i * 8}" height="6" rx="3" fill="{a}" opacity=".6"/>'
                      for i in range(4)))

def art_war(a, k):
    return (f'<path d="M-80,-80 L70,70 M80,-80 L-70,70" stroke="{a}" stroke-width="12" stroke-linecap="round"/>'
            f'<path d="M-95,-95 L-70,-70 M95,-95 L70,-70" stroke="{a}" stroke-width="22" stroke-linecap="round"/>'
            f'<circle r="26" fill="{k}" stroke="{a}" stroke-width="6"/>')

def art_history(a, k):
    return (f'<rect x="-75" y="-80" width="150" height="16" fill="{a}"/><rect x="-85" y="80" width="170" height="16" fill="{a}"/>'
            + "".join(f'<rect x="{x}" y="-60" width="18" height="138" fill="{a}"/>' for x in (-62, -28, 10, 44))
            + f'<path d="M-90,-80 L0,-112 L90,-80 Z" fill="{a}"/>')

def art_biography(a, k):
    return (f'<path d="M10,-90 C-40,-95 -60,-55 -55,-25 C-70,-5 -62,5 -52,8 C-56,25 -48,40 -30,42 C-30,60 -40,80 -50,95 L60,95 '
            f'C45,70 40,40 55,10 C75,-30 60,-85 10,-90 Z" fill="{a}"/>')

def art_adventure(a, k):
    return (f'<circle cx="35" cy="-50" r="35" fill="{a}"/>'
            f'<path d="M-110,90 L-40,-30 L0,20 L40,-60 L110,90 Z" fill="{k}" opacity=".85"/>'
            f'<path d="M40,-60 L25,-35 L40,-40 L55,-35 Z M-40,-30 L-52,-10 L-40,-14 L-28,-10 Z" fill="{a}"/>')

def art_animation(a, k):
    return "".join(f'<path d="M{x},{y} l{s*.3},{s*.7} l{s*.7},{s*.3} l{-s*.7},{s*.3} l{-s*.3},{s*.7} l{-s*.3},{-s*.7} '
                   f'l{-s*.7},{-s*.3} l{s*.7},{-s*.3} Z" fill="{a}"/>' for x, y, s in [(-10, -70, 70), (55, 10, 40), (-60, 30, 32)])

def art_documentary(a, k):
    return (f'<circle r="80" fill="none" stroke="{a}" stroke-width="10"/><circle r="52" fill="none" stroke="{a}" stroke-width="6"/>'
            f'<circle r="24" fill="{a}"/>')

def art_default(a, k):
    holes = "".join(f'<circle cx="{40 * __import__("math").cos(t)}" cy="{40 * __import__("math").sin(t)}" r="15" fill="{k}"/>'
                    for t in [i * 1.2566 for i in range(5)])
    return f'<circle r="80" fill="{a}"/>{holes}<circle r="10" fill="{k}"/>'

ART = {"Action": art_action, "Romance": art_romance, "Comedy": art_comedy, "Drama": art_drama, "Thriller": art_thriller,
       "Crime": art_crime, "Horror": art_horror, "Mystery": art_mystery, "Sci-Fi": art_scifi, "Fantasy": art_fantasy,
       "Family": art_family, "Music": art_music, "Musical": art_music, "Sport": art_sport, "War": art_war,
       "History": art_history, "Biography": art_biography, "Adventure": art_adventure, "Animation": art_animation,
       "Documentary": art_documentary}


# ------------------------------------------------------------------ helpers
def shift(hex_colour, amount):
    """Lighten (amount > 0) or darken (amount < 0) a colour slightly, for per-movie variety."""
    r, g, b = (int(hex_colour[i:i + 2], 16) for i in (1, 3, 5))
    f = lambda c: max(0, min(255, int(c + (255 - c) * amount if amount > 0 else c * (1 + amount))))
    return f"#{f(r):02x}{f(g):02x}{f(b):02x}"


def wrap_title(title, max_chars):
    lines, line = [], ""
    for word in title.split():
        if line and len(line) + 1 + len(word) > max_chars:
            lines.append(line)
            line = word
        else:
            line = f"{line} {word}".strip()
    lines.append(line)
    if len(lines) > 3:
        lines = lines[:2] + [" ".join(lines[2:])]
    return lines


def background_pattern(rng, colour):
    kind = rng.choice(["rays", "stripes", "dots", "rings"])
    if kind == "rays":
        cx, cy = rng.randint(120, 280), rng.randint(170, 260)
        return "".join(f'<polygon points="{cx},{cy} {cx + 900 * __import__("math").cos(t)},{cy + 900 * __import__("math").sin(t)} '
                       f'{cx + 900 * __import__("math").cos(t + .13)},{cy + 900 * __import__("math").sin(t + .13)}" fill="{colour}" opacity=".07"/>'
                       for t in [i * .26 for i in range(24)])
    if kind == "stripes":
        angle = rng.choice([-30, -18, 18, 30])
        return (f'<g transform="rotate({angle} 200 300)" opacity=".07">'
                + "".join(f'<rect x="-300" y="{y}" width="1000" height="18" fill="{colour}"/>' for y in range(-300, 900, 46)) + "</g>")
    if kind == "dots":
        return "".join(f'<circle cx="{x}" cy="{y}" r="{2 + (y / 600) * 4:.1f}" fill="{colour}" opacity=".1"/>'
                       for y in range(10, 600, 26) for x in range(10 + (y // 26 % 2) * 13, 400, 26))
    cx, cy = rng.randint(100, 300), rng.randint(150, 280)
    return "".join(f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="none" stroke="{colour}" stroke-width="10" opacity=".07"/>'
                   for r in range(40, 700, 40))


# ------------------------------------------------------------------ the poster
def make_poster_svg(movie):
    """movie: a row with title, year, language, genre_list, lead_actor, lead_actress, director, movie_id."""
    rng = random.Random(int(hashlib.md5(movie.movie_id.encode()).hexdigest(), 16))
    # main picture: usually the first genre, sometimes another of the film's genres (more variety)
    known = [g for g in movie.genre_list if g in THEMES]
    genre = rng.choice(known[:1] * 3 + known[1:]) if known else None
    top, bottom, art_colour, text_colour = THEMES.get(genre, DEFAULT_THEME)
    top, bottom = shift(top, rng.uniform(-.28, .18)), shift(bottom, rng.uniform(-.3, .2))
    art_colour = shift(art_colour, rng.uniform(-.15, .1))

    # artwork: genre picture, nudged and turned differently for each film
    x, y = 200 + rng.randint(-45, 45), 230 + rng.randint(-35, 20)
    scale, angle = rng.uniform(.95, 1.45), rng.randint(-16, 16)
    draw = ART.get(genre, art_default)
    if genre == "Comedy":                 # the most common genre gets three different pictures
        draw = rng.choice([art_comedy, art_comedy_wink, art_comedy_bubble])
    art = draw(art_colour, bottom)
    second = next((g for g in movie.genre_list if g in ART and g != genre), None)
    extra = ""
    if second:   # a small badge of the second genre in a corner
        sx, sy = rng.choice([(70, 120), (330, 120), (325, 370)])
        extra = f'<g transform="translate({sx},{sy}) scale(.32)" opacity=".55">{ART[second](art_colour, bottom)}</g>'

    # title
    title = re.sub(r"\s*\([^)]*film\)$", "", movie.title).upper()     # drop "(2007 Indian film)"
    max_chars = 11 if len(title) > 22 else 13
    lines = wrap_title(title, max_chars)
    longest = max(len(l) for l in lines)
    size = int(min(84, 340 / (0.66 * max(longest, 4))))
    title_bottom = 528
    title_svg = "".join(
        f'<text x="200" y="{title_bottom - (len(lines) - 1 - i) * size * 0.95:.0f}" text-anchor="middle" '
        f'font-family="Impact, Haettenschweiler, \'Arial Narrow Bold\', \'Arial Black\', sans-serif" font-size="{size}" '
        f'fill="{text_colour}" letter-spacing="1"'
        + (' textLength="340" lengthAdjust="spacingAndGlyphs"' if len(line) * size * 0.6 > 340 else "")
        + f'>{escape(line)}</text>'
        for i, line in enumerate(lines))

    stars = [p for p in (movie.lead_actor, movie.lead_actress) if p and p != "Unknown"]
    stars = "  |  ".join(stars).upper()        # e.g. "MOHANLAL  |  MEENA", on one centred line that always fits
    star_size = 17 if len(stars) <= 28 else 14
    fit = ' textLength="360" lengthAdjust="spacingAndGlyphs"' if len(stars) * star_size * 0.72 > 360 else ""
    stars_svg = (f'<text x="200" y="44" text-anchor="middle" font-family="Arial, sans-serif" font-size="{star_size}" '
                 f'font-weight="bold" letter-spacing="2" fill="{text_colour}" xml:space="preserve"{fit}>{escape(stars)}</text>') if stars else ""
    director = movie.director if movie.director and movie.director != "Unknown" else ""
    credit = f"DIRECTED BY {director.upper()}" if director else f"A {movie.language.upper()} FILM"

    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 600" width="400" height="600">
<defs>
  <linearGradient id="bg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{top}"/><stop offset="1" stop-color="{bottom}"/></linearGradient>
  <radialGradient id="vig" cx=".5" cy=".42" r=".75"><stop offset=".55" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".55"/></radialGradient>
  <linearGradient id="foot" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".6"/></linearGradient>
</defs>
<rect width="400" height="600" fill="url(#bg)"/>
{background_pattern(rng, text_colour)}
<g transform="translate({x},{y}) rotate({angle}) scale({scale:.2f})">{art}</g>
{extra}
<rect y="330" width="400" height="270" fill="url(#foot)"/>
<rect width="400" height="600" fill="url(#vig)"/>
{stars_svg}
{title_svg}
<rect x="150" y="548" width="100" height="2" fill="{art_colour}" opacity=".8"/>
<text x="200" y="572" text-anchor="middle" font-family="Arial, sans-serif" font-size="{12 if len(credit) < 34 else 10}" letter-spacing="2" fill="{text_colour}" opacity=".85">{escape(credit)}</text>
<text x="200" y="589" text-anchor="middle" font-family="Arial, sans-serif" font-size="10" letter-spacing="3" fill="{text_colour}" opacity=".6">{escape(movie.language.upper())}  {movie.year}</text>
</svg>'''
