@echo off
title Download movie posters
cd /d "%~dp0"
set PY=python
where python >nul 2>nul || set PY=py
%PY% -c "import flask, pandas, requests" >nul 2>nul || %PY% -m pip install -r requirements.txt
%PY% download_posters.py
pause
