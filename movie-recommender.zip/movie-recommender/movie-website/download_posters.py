"""
Optional: download the real poster of every movie from Wikipedia in one go (about 10-20 minutes).
Without this, the website downloads each poster the first time it is shown, which is a little slower.

Posters are saved in static/posters/. Films with no poster on Wikipedia keep their generated poster.
You can stop it any time (close the window) and run it again later; it skips posters it already has.
"""
from concurrent.futures import ThreadPoolExecutor, as_completed

import app

ids = app.movies.movie_id.tolist()
print(f"Checking posters for {len(ids)} movies. Keep this window open...")
found = missing = 0
with ThreadPoolExecutor(max_workers=6) as pool:
    jobs = {pool.submit(app.download_poster, i): i for i in ids}
    for n, job in enumerate(as_completed(jobs), start=1):
        if job.result():
            found += 1
        else:
            missing += 1
        if n % 100 == 0 or n == len(ids):
            print(f"{n}/{len(ids)} done | real posters: {found} | no poster (generated one used): {missing}")
print("Finished. Start the website to see the posters.")
