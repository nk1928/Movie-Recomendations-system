@echo off
title Teen Patti Talkies
rem Double-click this file to start the website. Close this window to stop it.

rem Work inside the folder this .bat file is in, wherever it was started from
cd /d "%~dp0"

rem Find Python ("python" or the Windows "py" launcher)
set PY=python
where python >nul 2>nul || set PY=py
%PY% --version >nul 2>nul
if errorlevel 1 (
    echo Python was not found. Install Python from https://www.python.org/downloads/ and tick "Add Python to PATH".
    pause
    exit /b 1
)

rem Install the needed libraries the first time (skipped once they are installed)
%PY% -c "import flask, pandas, requests" >nul 2>nul
if errorlevel 1 (
    echo Installing Flask, pandas and requests for the first time...
    %PY% -m pip install -r requirements.txt
    if errorlevel 1 (
        echo Installing the libraries failed. Check your internet connection and try again.
        pause
        exit /b 1
    )
)

rem Open the browser a few seconds after the server starts
start "" cmd /c "timeout /t 4 /nobreak >nul & start http://127.0.0.1:5000"

echo.
echo Teen Patti Talkies is running at http://127.0.0.1:5000
echo Keep this window open while you use the website. Close it to stop the website.
echo.
%PY% app.py

rem Only reached if the website stops because of an error
echo.
echo The website stopped. Read the message above to see why.
pause
