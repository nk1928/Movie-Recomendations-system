"""
Optional: fill in missing movie posters AND exact YouTube trailer links from TMDB.

1. Make a free account at https://www.themoviedb.org/signup
2. Go to Settings -> API and request an API key (choose "Developer", it is free).
3. Paste the key (the "API Key", not the long "Read Access Token") below and run:
       python fetch_posters.py
   It takes roughly 15-25 minutes for all 6,249 movies. Progress is saved every 100 movies,
   so you can stop it (Ctrl+C) and run it again later; it continues where it stopped.
4. Restart app.py. Posters and "Watch trailer" links now use the TMDB data.
"""
import time
from pathlib import Path
import pandas as pd
import requests

MOVIES_FILE = Path(__file__).parent / "movies.csv"   # always the movies.csv next to this script

TMDB_API_KEY = "PASTE_YOUR_TMDB_API_KEY_HERE"
REPLACE_EXISTING_POSTERS = False   # True = also replace the smaller Wikipedia posters with TMDB ones

API = "https://api.themoviedb.org/3"
IMAGE = "https://image.tmdb.org/t/p/w342"

movies = pd.read_csv(MOVIES_FILE, dtype={"movie_id": str}, keep_default_na=False)
if "trailer_url" not in movies.columns:
    movies["trailer_url"] = ""
if "tmdb_checked" not in movies.columns:
    movies["tmdb_checked"] = False
movies["tmdb_checked"] = movies["tmdb_checked"].astype(str).isin(["True", "true", "1"])
movies["poster_url"] = movies["poster_url"].fillna("")
movies["trailer_url"] = movies["trailer_url"].fillna("")


def get(path, **params):
    params["api_key"] = TMDB_API_KEY
    for attempt in range(3):
        r = requests.get(API + path, params=params, timeout=15)
        if r.status_code == 429:            # too many requests: wait and retry
            time.sleep(2)
            continue
        if r.status_code == 401:
            raise SystemExit("TMDB rejected the API key. Check TMDB_API_KEY at the top of this file.")
        return r.json() if r.ok else {}
    return {}


def best_trailer(videos):
    yt = [v for v in videos.get("results", []) if v.get("site") == "YouTube"]
    yt.sort(key=lambda v: (v.get("type") != "Trailer", not v.get("official", False)))
    return f"https://www.youtube.com/watch?v={yt[0]['key']}" if yt else ""


todo = movies.index[~movies["tmdb_checked"]]
print(f"{len(todo)} movies left to check")
for n, i in enumerate(todo, start=1):
    row = movies.loc[i]
    found = get(f"/find/{row.movie_id}", external_source="imdb_id").get("movie_results", [])
    if found:
        tmdb = found[0]
        if tmdb.get("poster_path") and (row.poster_url == "" or REPLACE_EXISTING_POSTERS):
            movies.at[i, "poster_url"] = IMAGE + tmdb["poster_path"]
        if row.trailer_url == "":
            trailer = best_trailer(get(f"/movie/{tmdb['id']}/videos"))
            if not trailer:                  # many Indian trailers are only listed under the original language
                trailer = best_trailer(get(f"/movie/{tmdb['id']}/videos", include_video_language="hi,ta,te,ml,kn,en"))
            movies.at[i, "trailer_url"] = trailer
    movies.at[i, "tmdb_checked"] = True
    time.sleep(0.05)
    if n % 100 == 0 or n == len(todo):
        movies.to_csv(MOVIES_FILE, index=False)
        print(f"{n}/{len(todo)} checked | posters: {(movies.poster_url != '').sum()} | "
              f"exact trailers: {(movies.trailer_url != '').sum()}")

print("Done. Restart app.py to see the new posters and trailer links.")
