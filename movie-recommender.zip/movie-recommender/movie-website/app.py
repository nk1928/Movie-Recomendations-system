"""
Teen Patti Talkies: Indian movie recommendation website (Flask)

Run:   double-click run_website.bat   (or: pip install -r requirements.txt, then python app.py)
Open:  http://127.0.0.1:5000

Needs movies.csv and recommendations.json (made by train_model.ipynb) in this folder.
"""
import json
import random
import re
import threading
from pathlib import Path
from urllib.parse import quote_plus

import pandas as pd
import requests
from flask import Flask, render_template, request, redirect, url_for, session, jsonify, abort, make_response, send_file

from poster_art import make_poster_svg

SITE_NAME = "Teen Patti Talkies"          # change the site name here

app = Flask(__name__)
app.secret_key = "replace-this-with-any-long-random-sentence"   # signs the cookie that remembers viewed movies

# app.root_path is the folder that contains app.py, so files are found from wherever you start the site
FOLDER = app.root_path
POSTER_FOLDER = f"{FOLDER}/static/posters"   # real posters are downloaded here and kept
MISSING_FILE = f"{FOLDER}/static/posters/_not_on_wikipedia.json"


# ---------------------------------------------------------------- data & model
# CSV and JSON work with any pandas/Python version (pickle files only open with the version that made them)
movies = pd.read_csv(f"{FOLDER}/movies.csv", dtype={"movie_id": str}, keep_default_na=False)   # one row per movie
with open(f"{FOLDER}/recommendations.json", encoding="utf-8") as f:
    recommendations = json.load(f)        # movie_id -> [[similar_movie_id, similarity], ...] top 20

if "trailer_url" not in movies.columns:   # added by fetch_posters.py if you run it
    movies["trailer_url"] = ""
movies["genre_list"] = movies["genre"].str.split(", ")
movies = movies.set_index("movie_id", drop=False)

GENRES = sorted({g for gl in movies.genre_list for g in gl})
LANGUAGES = movies.language.value_counts().index.tolist()
# most frequent names first, so suggestions show well-known people before rare ones
PEOPLE = [p for p in pd.concat([movies.lead_actor, movies.lead_actress]).value_counts().index if p != "Unknown"]
DIRECTORS = [d for d in movies.director.str.split(", ").explode().value_counts().index if d != "Unknown"]

# well-liked, reasonably known films: used for the surprise cards and the "movies to try" list
good = movies[(movies.rating >= 6.5) & (movies.votes >= 300)]


def trailer_link(m):
    if m.trailer_url:                     # exact YouTube link (only after fetch_posters.py)
        return m.trailer_url
    query = f"{m.title} {m.year} {m.language} movie official trailer"
    return "https://www.youtube.com/results?search_query=" + quote_plus(query)


def card(movie_id):
    """Small dict with what a poster card needs."""
    m = movies.loc[movie_id]
    return {"id": m.movie_id, "title": m.title, "year": int(m.year), "language": m.language,
            "rating": float(m.rating), "genre": m.genre_list[0]}


def random_cards(n, exclude=()):
    pool = good[~good.movie_id.isin(exclude)]
    return [card(i) for i in pool.sample(n).movie_id]


@app.context_processor
def inject_globals():
    return {"site_name": SITE_NAME, "genres": GENRES, "languages": LANGUAGES}


# ---------------------------------------------------------------- posters
# 1) A real poster already downloaded in static/posters/  -> use it
# 2) Otherwise ask Wikipedia for the film's poster, download it once into static/posters/, use it
# 3) No poster anywhere -> a unique poster drawn for the film from its genre, title, stars and director
WIKI_API = "https://en.wikipedia.org/w/api.php"
HEADERS = {"User-Agent": "TeenPattiTalkies/1.0 (student movie recommender project)"}
lock = threading.Lock()
Path(POSTER_FOLDER).mkdir(parents=True, exist_ok=True)
try:
    with open(MISSING_FILE, encoding="utf-8") as f:
        not_on_wikipedia = set(json.load(f))
except (FileNotFoundError, json.JSONDecodeError):
    not_on_wikipedia = set()


def simplify(text):
    return re.sub(r"[^a-z0-9]", "", text.lower())


def find_wikipedia_poster(m):
    """Search Wikipedia for '<title> <year> <language> film' and return the article's main image URL."""
    params = {"action": "query", "format": "json", "formatversion": 2, "redirects": 1,
              "generator": "search", "gsrsearch": f"{m.title} {m.year} {m.language} film", "gsrlimit": 5,
              "gsrnamespace": 0, "prop": "pageimages|description", "piprop": "thumbnail", "pithumbsize": 400}
    pages = requests.get(WIKI_API, params=params, headers=HEADERS, timeout=8).json()
    pages = sorted(pages.get("query", {}).get("pages", []), key=lambda p: p.get("index", 99))
    want, year = simplify(re.sub(r"\(.*?film\)", "", m.title)), str(m.year)
    for page in pages:
        name = simplify(re.sub(r"\(.*?\)", "", page["title"]))          # "Premam (2015 film)" -> "premam"
        about = (page.get("description", "") + " " + page["title"]).lower()
        same_title = name == want or (len(want) > 3 and (name.startswith(want) or want.startswith(name)))
        is_this_film = "film" in about and (year in about or name == want)
        if same_title and is_this_film and "thumbnail" in page:
            return page["thumbnail"]["source"]
    return ""


def local_poster(movie_id):
    path = f"{POSTER_FOLDER}/{movie_id}.jpg"
    return path if Path(path).exists() else None


def download_poster(movie_id):
    """Returns the saved file path, or None if the film has no poster on Wikipedia (or there is no internet)."""
    if local_poster(movie_id):
        return local_poster(movie_id)
    if movie_id in not_on_wikipedia:
        return None
    m = movies.loc[movie_id]
    try:
        url = m.poster_url if "tmdb.org" in m.poster_url else find_wikipedia_poster(m)
        image = requests.get(url, headers=HEADERS, timeout=10) if url else None
        if image is None or not image.ok or not image.headers.get("Content-Type", "").startswith("image"):
            with lock:
                not_on_wikipedia.add(movie_id)
                with open(MISSING_FILE, "w", encoding="utf-8") as f:
                    json.dump(sorted(not_on_wikipedia), f)
            return None
    except (requests.RequestException, ValueError):
        return None                       # no internet right now: try again next time
    path = f"{POSTER_FOLDER}/{movie_id}.jpg"
    with open(path, "wb") as f:
        f.write(image.content)
    return path


@app.route("/poster/<movie_id>")
def poster(movie_id):
    if movie_id not in movies.index:
        abort(404)
    path = download_poster(movie_id)
    if path:
        response = send_file(path, mimetype="image/jpeg", max_age=7 * 86400)
    else:
        response = make_response(make_poster_svg(movies.loc[movie_id]))
        response.headers["Content-Type"] = "image/svg+xml"
        response.headers["Cache-Control"] = "no-cache"   # check again later in case a real poster appears
    return response


@app.route("/poster-art/<movie_id>.svg")
def poster_art(movie_id):
    """The generated poster on its own (also used if a real poster fails to load)."""
    if movie_id not in movies.index:
        abort(404)
    response = make_response(make_poster_svg(movies.loc[movie_id]))
    response.headers["Content-Type"] = "image/svg+xml"
    return response


# ---------------------------------------------------------------- "because you watched" (no account needed)
# The browser cookie remembers the last 15 movies opened on this computer.
def viewed_ids():
    return [i for i in session.get("viewed", []) if i in movies.index]


def remember_view(movie_id):
    viewed = [movie_id] + [i for i in viewed_ids() if i != movie_id]
    session["viewed"] = viewed[:15]


def personal_recommendations(viewed, n=24):
    """Blend the trained KNN neighbours of recently opened movies (recent ones count more)."""
    seen = set(viewed)
    scores, votes = {}, {}
    for rank, mid in enumerate(viewed):
        weight = 1.0 / (1 + 0.2 * rank)
        for sim_id, sim in recommendations.get(mid, []):
            if sim_id not in seen:
                scores[sim_id] = scores.get(sim_id, 0) + weight * sim
                votes[sim_id] = votes.get(sim_id, 0) + 1
    # movies similar to several of your films first, then take turns so one film can't fill the row
    best = sorted([i for i in scores if votes[i] > 1], key=scores.get, reverse=True)
    queues = [[s for s, _ in recommendations.get(mid, []) if s not in seen] for mid in viewed]
    while len(best) < n and any(queues):
        for q in queues:
            while q and q[0] in best:
                q.pop(0)
            if q:
                best.append(q.pop(0))
    return [card(i) for i in best[:n]]


# ---------------------------------------------------------------- pages
@app.route("/")
def home():
    surprise = random_cards(3)
    viewed = viewed_ids()
    if viewed:
        picks = personal_recommendations(viewed)
        names = ", ".join(movies.loc[i].title for i in viewed[:3])
        picks_title, picks_note = "Because you watched", f"Picked by the trained model from films you opened: {names}."
    else:
        picks = random_cards(24, exclude=[c["id"] for c in surprise])
        picks_title, picks_note = "Movies to try tonight", "Open a few films and this row starts recommending similar ones."
    top = movies[movies.votes >= 2000].sort_values("rating", ascending=False).head(40).sample(12)
    page = make_response(render_template(
        "index.html", surprise=surprise, picks=picks, picks_title=picks_title, picks_note=picks_note,
        recent=[card(i) for i in viewed[:12]], top=[card(i) for i in top.movie_id]))
    page.headers["Cache-Control"] = "no-store, max-age=0"   # pressing Back always deals three new cards
    return page


@app.route("/forget")
def forget():
    session.pop("viewed", None)
    return redirect(url_for("home"))


@app.route("/search")
def search():
    kind = request.args.get("type", "movie")
    q = request.args.get("q", "").strip()
    lang = request.args.get("language", "")
    res = movies
    if lang:
        res = res[res.language == lang]
    if q:
        ql = q.lower()
        if kind == "movie":
            res = res[res.title.str.lower().str.contains(ql, regex=False)]
        elif kind == "actor":
            res = res[res.lead_actor.str.lower().str.contains(ql, regex=False)
                      | res.lead_actress.str.lower().str.contains(ql, regex=False)
                      | res.cast.str.lower().str.contains(ql, regex=False)]
        elif kind == "genre":
            res = res[res.genre_list.map(lambda gl: any(ql == x.lower() for x in gl))]
        elif kind == "director":
            res = res[res.director.str.lower().str.contains(ql, regex=False)]
    elif not lang:
        return redirect(url_for("home"))
    sort = request.args.get("sort", "popular")
    res = res.sort_values("rating" if sort == "rating" else "votes", ascending=False)
    return render_template("search.html", results=[card(i) for i in res.movie_id[:60]], total=len(res),
                           q=q, kind=kind, lang=lang, sort=sort)


@app.route("/api/suggest")
def suggest():
    """Autocomplete for the search box."""
    kind, q = request.args.get("type", "movie"), request.args.get("q", "").strip().lower()
    if len(q) < 2:
        return jsonify([])
    source = {"movie": movies.sort_values("votes", ascending=False).title.drop_duplicates().tolist(),
              "actor": PEOPLE, "genre": GENRES, "director": DIRECTORS}.get(kind, [])
    starts = [s for s in source if s.lower().startswith(q)]
    contains = [s for s in source if q in s.lower() and s not in starts]
    return jsonify((starts + contains)[:8])


@app.route("/movie/<movie_id>")
def movie(movie_id):
    if movie_id not in movies.index:
        abort(404)
    remember_view(movie_id)
    m = movies.loc[movie_id]
    similar = [card(i) for i, _ in recommendations.get(movie_id, [])[:12]]
    cast = [c for c in m.cast.split(", ") if c not in (m.lead_actor, m.lead_actress)]
    return render_template("movie.html", m=m, cast=cast, similar=similar,
                           trailer=trailer_link(m), exact_trailer=bool(m.trailer_url))


@app.route("/random")
def random_movie():
    return redirect(url_for("movie", movie_id=random.choice(good.movie_id.tolist())))


@app.errorhandler(404)
def not_found(e):
    return render_template("404.html"), 404


if __name__ == "__main__":
    app.run(debug=True, threaded=True)
